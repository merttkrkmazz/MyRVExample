package com.example.myrvexample.model

data class Place(val name: String, val location: String, val description: String, val bestTimeToVisit : String, val imageResId: Int)